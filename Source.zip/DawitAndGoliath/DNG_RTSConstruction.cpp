// Fill out your copyright notice in the Description page of Project Settings.

#include "DNG_RTSConstruction.h"

ADNG_RTSConstruction::ADNG_RTSConstruction() : Super()
{
	bReplicates = true;

	bIsMovable = false;
}

void ADNG_RTSConstruction::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

void ADNG_RTSConstruction::BeginPlay()
{
	Super::BeginPlay();

}
