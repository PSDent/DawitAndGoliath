// Fill out your copyright notice in the Description page of Project Settings.

#include "DNG_RTSUnitAIController.h"

ADNG_RTSUnitAIController::ADNG_RTSUnitAIController() : Super()
{
	
}