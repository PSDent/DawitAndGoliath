// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "DNG_RTSConstruction.h"
#include "DNG_RTSObstruction.generated.h"

/**
 * 
 */
UCLASS()
class DAWITANDGOLIATH_API ADNG_RTSObstruction : public ADNG_RTSConstruction
{
	GENERATED_BODY()
	
};
