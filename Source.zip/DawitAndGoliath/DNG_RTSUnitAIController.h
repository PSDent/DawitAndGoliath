// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "AIController.h"
#include "DNG_RTSUnitAIController.generated.h"

/**
 * 
 */
UCLASS()
class DAWITANDGOLIATH_API ADNG_RTSUnitAIController : public AAIController
{
	GENERATED_BODY()
	
public:
	ADNG_RTSUnitAIController();

private:

protected:

public:

private:

protected:


};
